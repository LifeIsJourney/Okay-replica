﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockManager : MonoBehaviour
{
    public List<Block>TotalNoOfBlocks;

    public int totalBlockCount;
    public int destroyedBlockCount;
    // Start is called before the first frame update
    void Start()
    {
        TotalNoOfBlocks = new List<Block>();
       
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void SetBlock(Block block)
    {
        TotalNoOfBlocks.Add(block);
        totalBlockCount++;
    }
    public void RemoveBlock(Block block)
    {
        destroyedBlockCount++;
    }
}
