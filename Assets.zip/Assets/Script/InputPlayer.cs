﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputPlayer : MonoBehaviour
{
    bool isPressed;
    bool isHeld;
    bool isRelease;

    Vector2  startingMousePosotion;
    Vector2  endMousePosition;

    Rigidbody2D rgbd;

    public float MoveSpeed;
    PlayerEffect effect;

    public LayerMask layerToCollide;
    bool checkIfInside;
    SpriteRenderer sr;
    // Start is called before the first frame update
    void Start()
    {
        rgbd = GetComponent<Rigidbody2D>();
        effect = GetComponent<PlayerEffect>();
        sr = GetComponentInChildren<SpriteRenderer>();
        SetSpriteActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        CheckMouseState();
        TakeMousePosition();
        
    }
    void CheckMouseState()
    {
        isPressed = Input.GetMouseButtonDown(0);
        isHeld = Input.GetMouseButton(0);
        isRelease = Input.GetMouseButtonUp(0);
    }
    void TakeMousePosition()
    {
        if (isPressed)
        {
            SetSpriteActive(true);
            checkIfInside = checkIfInsideBlock();
            if (checkIfInside) return;
            startingMousePosotion = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            ResetPlayerPosition();
            effect.SnapPlayerPos(startingMousePosotion);
            effect.SetDotState(true);
            effect.SetTrailVisible(false);
        }
        if (isHeld)
        {
            if (checkIfInside) return;
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            effect.SetDotsPos(startingMousePosotion, mousePos);
        }
        if (isRelease)
        {
            if (checkIfInside) return;
            endMousePosition  = Camera.main.ScreenToWorldPoint(Input.mousePosition);
             MoveThePlayer();
            effect.SetDotState(false);
            effect.SetTrailVisible(true);
        }
    }
    void MoveThePlayer()
    { Vector2 dir = (endMousePosition- startingMousePosotion).normalized;
        rgbd.velocity = MoveSpeed * dir;
    }

    void ResetPlayerPosition()
    {
        transform.position = startingMousePosotion;
        rgbd.velocity = Vector2.zero;
    }
    public void OnCollisionEnter2D(Collision2D collision)
    {
        Vector2 dir;
        Vector2 normal;
        if (collision.collider.tag == ("Square"))
        { normal = collision.contacts[0].normal;
            dir = Vector2.Reflect(rgbd.velocity, normal).normalized;
            rgbd.velocity = dir * MoveSpeed;
        }
    }
    bool checkIfInsideBlock()
    { Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        bool check = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity, layerToCollide);
        if (check)
        {
            return true;
        }
        return false;
    }
    void SetSpriteActive(bool value)
    {
        sr.enabled = value;
    }
}
//first player movement
/*
 *  bool isPressed;
    bool isHeld;
    bool isRelease;

    Vector2  startingMousePosotion;
    Vector2  endMousePosition;

    Rigidbody2D rgbd;

    public float MoveSpeed;

    // Start is called before the first frame update
    void Start()
    {
        rgbd = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        CheckMouseState();
        TakeMousePosition();
        
    }
    void CheckMouseState()
    {
        isPressed = Input.GetMouseButtonDown(0);
        isHeld = Input.GetMouseButton(0);
        isRelease = Input.GetMouseButtonUp(0);
    }
    void TakeMousePosition()
    {
        if (isPressed)
        {
            startingMousePosotion = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        }
        if (isRelease)
        {
            endMousePosition  = Camera.main.ScreenToWorldPoint(Input.mousePosition);
             MoveThePlayer();
            
        }
    }
    void MoveThePlayer()
    { Vector2 dir = (endMousePosition- startingMousePosotion).normalized;
        rgbd.velocity = MoveSpeed * dir;
    }
 */
