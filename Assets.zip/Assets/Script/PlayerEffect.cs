﻿
using UnityEngine;

public class PlayerEffect : MonoBehaviour
{   [SerializeField]
    private GameObject dorPrefab;
    int dotAmount;

    float dorGap;

    GameObject[] dotArray;

    public AnimationCurve speedCurve;
    public float followSpeed;

    TrailRenderer trail;

    // Start is called before the first frame update
    void Start()
    {
        dotAmount = 10;
        dorGap = 1f/dotAmount;
        SpawnDots();
        trail = GetComponentInChildren<TrailRenderer>();
    }

    // Update is called once per frame
    void SpawnDots()
    {
        dotArray = new GameObject[dotAmount];
        for (int i = 0; i < dotAmount; i++)
        {
            GameObject dot = Instantiate(dorPrefab);
            dot.SetActive(false);
            dotArray[i] = dot;
        }
    }
    public void SetDotsPos(Vector2 startPos,Vector2 endPos)
    {
        for (int i = 0; i < dotAmount; i++)
        {    Vector2 dotPos = dotArray[i].transform.position;
            Vector2 targetPos = Vector2.Lerp(startPos, endPos, i * dorGap);

            float smoothSpeed = (1- speedCurve.Evaluate(i * dorGap)) * followSpeed;

            dotArray[i].transform.position = Vector2.Lerp(dotPos, targetPos, smoothSpeed * Time.deltaTime);
        }
    }
    public void SetDotState(bool state)
    {
        for (int i = 0; i < dotAmount; i++)
        {
            dotArray[i].SetActive(state);
        }
    }

    public void SnapPlayerPos(Vector2 startingMousePosotion)
    {
        Vector2 snapPos = startingMousePosotion;
        for (int i = 0; i < dotAmount; i++)
        {
           
            dotArray[i].transform.position = snapPos;
        }
       
    }
    public void SetTrailVisible(bool isVisible)
    {
        trail.enabled = isVisible;
    }
}
