﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block : MonoBehaviour
{
    BlockManager Bmanager;
    public void Start()
    {
        Bmanager = GetComponentInParent<BlockManager>();
        Bmanager.SetBlock(this);
    }
    public void OnCollisionEnter2D(Collision2D collision)
    {   if (collision.collider.GetComponent<InputPlayer>() == null) return;
        Bmanager.RemoveBlock(this);
        gameObject.SetActive(false);
    }
}
